@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "venv\Scripts\python.exe" (
  echo Спочатку запустіть install_windows.bat
  pause
  exit /b 1
)
venv\Scripts\python.exe manage.py runserver
pause
