from django.db import models
class Category(models.Model):
    name = models.CharField(max_length=100)
    order = models.PositiveIntegerField(default=0)
    def __str__(self): return self.name
    class Meta: ordering = ["order", "name"]

class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products")
    name = models.CharField(max_length=160)
    description = models.CharField(max_length=240, blank=True)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    unit = models.CharField(max_length=30, default="1 шт.")
    image = models.ImageField(upload_to="products/", blank=True)
    available = models.BooleanField(default=True)
    featured = models.BooleanField(default=False)
    def __str__(self): return self.name
    class Meta: ordering = ["category__order", "name"]

class Order(models.Model):
    DELIVERY = "delivery"
    PICKUP = "pickup"
    METHOD_CHOICES = [(DELIVERY, "Доставка"), (PICKUP, "Самовивіз")]
    STATUS_CHOICES = [
        ("new", "Нове"), ("contacted", "Зателефонували"),
        ("preparing", "Готується"), ("courier", "У кур’єра"),
        ("done", "Виконано"), ("cancelled", "Скасовано")
    ]
    created_at = models.DateTimeField(auto_now_add=True)
    first_name = models.CharField("Ім’я", max_length=80)
    last_name = models.CharField("Прізвище", max_length=80)
    patronymic = models.CharField("По батькові", max_length=80, blank=True)
    phone = models.CharField("Телефон", max_length=30)
    method = models.CharField("Отримання", max_length=20, choices=METHOD_CHOICES)
    address = models.CharField("Адреса доставки / примітка", max_length=250, blank=True)
    desired_time = models.CharField("Бажаний час", max_length=80, blank=True)
    comment = models.TextField("Коментар", blank=True)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    status = models.CharField("Статус", max_length=20, choices=STATUS_CHOICES, default="new")
    def __str__(self): return f"Замовлення №{self.pk} — {self.first_name} {self.last_name}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product_name = models.CharField(max_length=160)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    quantity = models.PositiveIntegerField(default=1)
    def __str__(self): return f"{self.product_name} × {self.quantity}"

class Review(models.Model):
    name = models.CharField(max_length=80)
    text = models.TextField(max_length=800)
    created_at = models.DateTimeField(auto_now_add=True)
    approved = models.BooleanField(default=False)
    def __str__(self): return f"{self.name}: {self.text[:40]}"
