from decimal import Decimal
from django.contrib import messages
from django.db import transaction
from django.shortcuts import render, redirect, get_object_or_404
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST
from .models import Category, Product, Order, OrderItem, Review

PHONE = "+380372513187"

def cart_data(request):
    cart = request.session.get("cart", {})
    if not isinstance(cart, dict):
        cart = {}
        request.session["cart"] = cart
    items, total, count = [], Decimal("0.00"), 0
    for key, qty in list(cart.items()):
        try:
            product = Product.objects.get(pk=int(key), available=True)
            qty = max(1, min(99, int(qty)))
        except (Product.DoesNotExist, ValueError, TypeError):
            continue
        subtotal = product.price * qty
        items.append({"product": product, "quantity": qty, "subtotal": subtotal})
        total += subtotal
        count += qty
    return items, total, count

def home(request):
    categories = Category.objects.prefetch_related("products").all()
    items, total, count = cart_data(request)
    return render(request, "shop/home.html", {
        "categories": categories, "featured": Product.objects.filter(available=True, featured=True)[:4],
        "reviews": Review.objects.filter(approved=True)[:6], "cart_count": count, "phone": PHONE,
    })

@require_POST
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id, available=True)
    cart = request.session.get("cart", {})
    if not isinstance(cart, dict):
        cart = {}
    key = str(product.pk)
    try:
        current_quantity = int(cart.get(key, 0))
    except (TypeError, ValueError):
        current_quantity = 0
    cart[key] = min(99, max(0, current_quantity) + 1)
    request.session["cart"] = cart
    messages.success(request, f"«{product.name}» додано до кошика.")
    # The hidden field is a path (e.g. /#menu), not a Django URL name.
    # Validate it so a forged form cannot redirect visitors to another site.
    next_url = request.POST.get("next", "")
    if next_url and url_has_allowed_host_and_scheme(
        url=next_url, allowed_hosts={request.get_host()}, require_https=request.is_secure()
    ):
        return redirect(next_url)
    return redirect("home")

def cart(request):
    items, total, count = cart_data(request)
    return render(request, "shop/cart.html", {"items": items, "total": total, "cart_count": count, "phone": PHONE})

@require_POST
def update_cart(request, product_id):
    cart = request.session.get("cart", {})
    if not isinstance(cart, dict):
        cart = {}
    qty = request.POST.get("quantity", "1")
    try: qty = int(qty)
    except ValueError: qty = 1
    if qty <= 0: cart.pop(str(product_id), None)
    else: cart[str(product_id)] = min(99, qty)
    request.session["cart"] = cart
    return redirect("cart")

def checkout(request):
    items, total, count = cart_data(request)
    if not items:
        messages.info(request, "Спочатку додайте товари до кошика.")
        return redirect("home")
    if request.method == "POST":
        fields = ["first_name", "last_name", "patronymic", "phone", "method", "address", "desired_time", "comment"]
        data = {f: request.POST.get(f, "").strip() for f in fields}
        errors = []
        for field, label in [("first_name", "ім’я"), ("last_name", "прізвище"), ("phone", "номер телефону")]:
            if not data[field]: errors.append(f"Вкажіть {label}.")
        if data["method"] not in ("delivery", "pickup"): errors.append("Оберіть спосіб отримання.")
        if data["method"] == "delivery" and not data["address"]: errors.append("Вкажіть адресу доставки.")
        if data["method"] == "pickup":
            data["address"] = data["address"] or "Самовивіз"
        if errors:
            for e in errors: messages.error(request, e)
            return render(request, "shop/checkout.html", {"items": items, "total": total, "cart_count": count, "data": data, "phone": PHONE})
        with transaction.atomic():
            order = Order.objects.create(
                first_name=data["first_name"], last_name=data["last_name"], patronymic=data["patronymic"],
                phone=data["phone"], method=data["method"], address=data["address"],
                desired_time=data["desired_time"], comment=data["comment"], total=total
            )
            OrderItem.objects.bulk_create([OrderItem(order=order, product_name=x["product"].name,
                price=x["product"].price, quantity=x["quantity"]) for x in items])
        request.session["last_order_id"] = order.pk
        request.session["cart"] = {}
        return redirect("order_success")
    return render(request, "shop/checkout.html", {"items": items, "total": total, "cart_count": count, "phone": PHONE})

def order_success(request):
    order_id = request.session.get("last_order_id")
    if not order_id: return redirect("home")
    order = get_object_or_404(Order, pk=order_id)
    return render(request, "shop/success.html", {"order": order, "cart_count": 0, "phone": PHONE})

@require_POST
def submit_review(request):
    name = request.POST.get("name", "").strip()
    text = request.POST.get("text", "").strip()
    if name and text:
        Review.objects.create(name=name[:80], text=text[:800])
        messages.success(request, "Дякуємо за відгук! Він з’явиться після перевірки.")
    else:
        messages.error(request, "Заповніть ім’я та текст відгуку.")
    return redirect("home")
