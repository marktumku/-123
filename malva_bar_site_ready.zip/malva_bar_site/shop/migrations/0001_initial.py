# Generated for Django 5.2
import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="Category",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=100)),
                ("order", models.PositiveIntegerField(default=0)),
            ],
            options={"ordering": ["order", "name"]},
        ),
        migrations.CreateModel(
            name="Product",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=160)),
                ("description", models.CharField(blank=True, max_length=240)),
                ("price", models.DecimalField(decimal_places=2, max_digits=8)),
                ("unit", models.CharField(default="1 шт.", max_length=30)),
                ("image", models.ImageField(blank=True, upload_to="products/")),
                ("available", models.BooleanField(default=True)),
                ("featured", models.BooleanField(default=False)),
                ("category", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="products", to="shop.category")),
            ],
            options={"ordering": ["category__order", "name"]},
        ),
        migrations.CreateModel(
            name="Order",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("first_name", models.CharField(max_length=80, verbose_name="Ім’я")),
                ("last_name", models.CharField(max_length=80, verbose_name="Прізвище")),
                ("patronymic", models.CharField(blank=True, max_length=80, verbose_name="По батькові")),
                ("phone", models.CharField(max_length=30, verbose_name="Телефон")),
                ("method", models.CharField(choices=[("delivery", "Доставка"), ("pickup", "Самовивіз")], max_length=20, verbose_name="Отримання")),
                ("address", models.CharField(blank=True, max_length=250, verbose_name="Адреса доставки / примітка")),
                ("desired_time", models.CharField(blank=True, max_length=80, verbose_name="Бажаний час")),
                ("comment", models.TextField(blank=True, verbose_name="Коментар")),
                ("total", models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ("status", models.CharField(choices=[("new", "Нове"), ("contacted", "Зателефонували"), ("preparing", "Готується"), ("courier", "У кур’єра"), ("done", "Виконано"), ("cancelled", "Скасовано")], default="new", max_length=20)),
            ],
        ),
        migrations.CreateModel(
            name="OrderItem",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("product_name", models.CharField(max_length=160)),
                ("price", models.DecimalField(decimal_places=2, max_digits=8)),
                ("quantity", models.PositiveIntegerField(default=1)),
                ("order", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="items", to="shop.order")),
            ],
        ),
        migrations.CreateModel(
            name="Review",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=80)),
                ("text", models.TextField(max_length=800)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("approved", models.BooleanField(default=False)),
            ],
        ),
    ]
