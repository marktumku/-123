from django.contrib import admin
from .models import Category, Product, Order, OrderItem, Review
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "order")
    ordering = ("order",)
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "price", "available", "featured")
    list_filter = ("category", "available")
    search_fields = ("name",)
    list_editable = ("price", "available", "featured")
class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ("product_name", "price", "quantity")
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "created_at", "first_name", "last_name", "phone", "method", "total", "status")
    list_filter = ("status", "method", "created_at")
    search_fields = ("first_name", "last_name", "phone", "address")
    list_editable = ("status",)
    inlines = [OrderItemInline]
    readonly_fields = ("created_at", "total")
@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ("name", "created_at", "approved")
    list_editable = ("approved",)
    list_filter = ("approved",)
