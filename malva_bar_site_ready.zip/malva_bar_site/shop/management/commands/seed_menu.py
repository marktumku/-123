from django.core.management.base import BaseCommand
from shop.models import Category, Product

MENU = [
("Гаряча їжа", [
("Гарячий бутерброд «Мальва»",85,"Фірмовий гарячий бутерброд",True),
]),
("Кава та чай", [
("Пакувальна коробка",14,"",False), ("Кава (еспресо / американо)",35,"",False),
("Вершки до кави",5,"",False), ("Чай",15,"1/200",False), ("Лимон",5,"1/10",False),
]),
("Снеки та солодощі", [
("Orbit жувальна гумка",25,"",False), ("Батончик в асортименті",45,"",False),
("Батончик Super +",75,"",False), ("Морозиво",40,"Додатково: джем — 5 грн; шоколад — 5 грн",False),
]),
("Безалкогольні напої", [
("Coca-Cola / Fanta / Sprite / Schweppes 0,33 л",40,"",False),
("Coca-Cola / Fanta / Sprite 1,75 л",120,"",False),
("Мінеральна вода газована / негазована 0,5 л",35,"",False),
("Сік в асортименті 0,25 л",40,"0,5 л — 70 грн; 1 л — 140 грн",False),
("Сік в асортименті 0,2 л",35,"",False),
("Холодний чай «Fuze»",45,"",False),
]),
("Пиво", [
("Пиво «Львівське 1715»",55,"",False),
("Пиво «Heineken» / «Stella Artois» 0,33 л",60,"",False),
("Пиво «Corona»",90,"",False),
("Пиво «Heineken» / «Carlsberg» / «Kronenbourg 1664 Blanc»",70,"",False),
("Пиво нефільтроване",70,"",False), ("Пиво безалкогольне",70,"",False),
]),
("Міцний алкоголь та барна карта", [
("Горілка «Медова з перцем»",25,"50 мл — 25 грн; 100 мл — 50 грн; 0,5 л — 250 грн",False),
("Горілка «Немирів» / «Немирів делікат»",25,"50 мл — 25 грн; 100 мл — 50 грн; 0,5 л — 250 грн",False),
("Горілка «Львівська Преміум»",35,"50 мл — 35 грн; 100 мл — 70 грн; 0,5 л — 250 грн",False),
("Горілка «Finlandia»",40,"50 мл — 40 грн; 100 мл — 80 грн; 0,5 л — 400 грн",False),
("Горілка «Zubrowka biala»",25,"50 мл — 25 грн; 100 мл — 50 грн; 0,5 л — 250 грн",False),
("Коньяк «Аджарі 4*» / «Довбуш»",40,"50 мл — 40 грн; 100 мл — 80 грн; 0,5 л — 400 грн",False),
("Коньяк «Закарпатський» / «Старий Кахеті 4*»",40,"50 мл — 40 грн; 100 мл — 80 грн; 0,5 л — 400 грн",False),
("Коньяк «Клінков V.S.»",55,"50 мл — 55 грн; 100 мл — 110 грн; 0,5 л — 550 грн",False),
("Коньяк «Клінков V.S.O.P.»",65,"50 мл — 65 грн; 100 мл — 130 грн; 0,5 л — 650 грн",False),
("Бренді «Metaxa 5*»",65,"50 мл — 65 грн; 100 мл — 130 грн; 0,5 л — 650 грн",False),
("Віскі «Jim Beam» / «Ballantine’s» / «Red Label»",85,"50 мл — 85 грн; 100 мл — 170 грн; 0,7 л — 1190 грн",False),
("Віскі «Wild Turkey»",90,"50 мл — 90 грн; 100 мл — 180 грн; 0,7 л — 1260 грн",False),
("Вино в асортименті",25,"50 мл — 25 грн; 100 мл — 50 грн; 0,75 л — 400 грн",False),
("Шампанське",210,"пляшка",False),
("Мартіні",35,"50 мл — 35 грн; 100 мл — 70 грн; 1 л — 700 грн",False),
("Лікер «Jim Beam Apple» / «Jim Beam Honey»",85,"50 мл — 85 грн; 100 мл — 170 грн; 0,7 л — 1190 грн",False),
("Лікер Jagermeister",70,"50 мл — 70 грн; 100 мл — 140 грн; 0,5 л — 700 грн",False),
]),
]
class Command(BaseCommand):
    help = "Creates the menu transcribed from the provided Malva Bar menu photo."
    def handle(self, *args, **kwargs):
        # Remove the old combined ice-cream/add-ons row from earlier demo builds.
        Product.objects.filter(name="Морозиво / джем / шоколад").delete()
        for order, (name, products) in enumerate(MENU, 1):
            category, _ = Category.objects.get_or_create(name=name, defaults={"order": order})
            category.order = order
            category.save()
            for product_name, price, description, featured in products:
                Product.objects.update_or_create(name=product_name, category=category, defaults={
                    "price": price, "description": description, "featured": featured, "available": True
                })
        self.stdout.write(self.style.SUCCESS("Меню додано. Перевірте ціни й фасування за фото в адмінпанелі."))
