@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === Встановлення Мальва Бар ===
py -m venv venv
if errorlevel 1 goto python_error
venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto install_error
venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto install_error
venv\Scripts\python.exe manage.py migrate
if errorlevel 1 goto install_error
venv\Scripts\python.exe manage.py seed_menu
if errorlevel 1 goto install_error
echo.
echo Готово! Тепер запустіть start_windows.bat
pause
exit /b 0
:python_error
echo Не знайдено Python launcher py. Встановіть Python 3.12 або 3.13 з опцією Add Python to PATH.
pause
exit /b 1
:install_error
echo Встановлення не завершилось. Перевірте повідомлення вище та інтернет-з'єднання.
pause
exit /b 1
